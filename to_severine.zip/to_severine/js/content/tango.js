PASEO['tango'] = {
    
    'en': {

    },

    'es': {

    },

    'fr' : {
        
    }
}
